<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/install', [App\Http\Controllers\SetupController::class, 'install'])->name('installApp');
Route::get('/token', [App\Http\Controllers\SetupController::class, 'token'])->name('gettoken');
Route::get('/nws-app', [App\Http\Controllers\SetupController::class, 'nwsapp'])->name('nwsapphome');

Route::post('/app-uninstall', [App\Http\Controllers\SetupController::class,'uninstallApp'])->name("uninstalled_");

Route::get('/upgrade_Basic', [App\Http\Controllers\SetupController::class, 'upgrade_Basic'])->name('upgradeBasicPlan');
Route::get('/upgrade_Pro', [App\Http\Controllers\SetupController::class, 'upgrade_Pro'])->name('upgradeProPlan');
//  -----------------   HOOKS  ROUTES 

Route::post('/create-producthook', [App\Http\Controllers\SetupController::class,'createProductHook'])->name("createProductHook_");
// Route::post('/update-producthook', [App\Http\Controllers\SetupController::class,'updateProductHook'])->name("updateProductHook_");
// Route::post('/delete-producthook', [App\Http\Controllers\SetupController::class,'deleteProductHook'])->name("deleteProductHook_");
// Route::post('/fulfill-orderhook', [App\Http\Controllers\SetupController::class,'fulfillOrderHook'])->name("fulfillOrderHook_");
// Route::post('/create-orderhook', [App\Http\Controllers\SetupController::class,'createOrderHook'])->name("createOrderHook_");
// Route::post('/paid-orderhook', [App\Http\Controllers\SetupController::class,'paidOrderHook'])->name("paidOrderHook_");
// Route::post('/cancel-orderhook', [App\Http\Controllers\SetupController::class,'cancelOrderHook'])->name("cancelOrderHook_");

//  -----------------   HOOKS  ROUTES 
