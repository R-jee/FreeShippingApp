@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Dashboard') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        {{ __('You are logged in asd !') }}
                        
                        
                        <iframe src="https://promotionking.info/ShopifyApp/Feed_monsterApp/?hmac=1973884133ed726939a2904de10bad53cac64313d2e612bf322c09fec3325a70&host=ZmVlZGJvb3N0ZXIubXlzaG9waWZ5LmNvbS9hZG1pbg&session=2b1a68953e9f3295f2366e68dc50821aa6ee10a4cf595078c9e55314626ea0c9&shop=feedbooster.myshopify.com&timestamp=1638431528" title="W3Schools Free Online Web Tutorials"></iframe>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    
        
    


@endsection


