<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php echo e(__('You are logged in asd !')); ?>

                        
                        
                        <iframe src="https://promotionking.info/ShopifyApp/Feed_monsterApp/?hmac=1973884133ed726939a2904de10bad53cac64313d2e612bf322c09fec3325a70&host=ZmVlZGJvb3N0ZXIubXlzaG9waWZ5LmNvbS9hZG1pbg&session=2b1a68953e9f3295f2366e68dc50821aa6ee10a4cf595078c9e55314626ea0c9&shop=feedbooster.myshopify.com&timestamp=1638431528" title="W3Schools Free Online Web Tutorials"></iframe>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    
        
    


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/promotionking/public_html/ShopifyApp/feedMonsterApp/resources/views/home.blade.php ENDPATH**/ ?>