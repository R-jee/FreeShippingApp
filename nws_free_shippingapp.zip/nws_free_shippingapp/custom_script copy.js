

var checkSum_price_previous = 0;
var checkSum_price = 0;


function cartUpdated_____() {
  jQuery.ajax({
    url: '/cart.js',
    type: "GET",
    dataType: "json",
    success: function (data) {
      checkSum_price = data.total_price / 100;
    },
    error: function (data) {
    },
  });
}
window.setInterval('cartUpdated_____()', 100);
var RESPONSE__Json_DATA = '';
function SYNC_BAR____function() {
  var xhttp = new XMLHttpRequest();
  // xhttp.open("GET", scriptPath + "ajax-get-messages-data?shop=" + shopPath + "&get_check=1", true);
  xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + "{{ shop.permanent_domain }}" + "&get_check=1", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      // console.log( JSON.parse(this.response) );
      localStorage.setItem("RESPONSE__Json_DATA", this.response);
    }
  };
  xhttp.send();
}
SYNC_BAR____function();

RESPONSE__Json_DATA = JSON.parse(localStorage.getItem("RESPONSE__Json_DATA"));

function SYNC______() {
  if( JSON.parse(RESPONSE__Json_DATA.Data).message_text != null){
    if (checkSum_price == 0) {
      $("#NWS_announcement_message_bar--id").remove();
      $('body').prepend(Shipping_banner('100% !important', 'middle', '6px', 'Arial, sans', '100%', '100%', 'inline-block', 'center', 'rgb(95, 4, 4)', 'white', '0.8em', JSON.parse(RESPONSE__Json_DATA.Data).message_text + " " + JSON.parse(RESPONSE__Json_DATA.Data).currency_ + " " + JSON.parse(RESPONSE__Json_DATA.Data).message_value));
    } else if (checkSum_price != 0 && checkSum_price < JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value) {
      var remaining_money_value = JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value - checkSum_price;
      $("#NWS_announcement_message_bar--id").remove();
      $('body').prepend(Shipping_banner('100% !important', 'middle', '6px', 'Arial, sans', '100%', '100%', 'inline-block', 'center', 'rgb(95, 4, 4)', 'white', '0.8em', JSON.parse(RESPONSE__Json_DATA.Data).progress_message_text1 + " " + JSON.parse(RESPONSE__Json_DATA.Data).currency_ + " " + remaining_money_value.toFixed(2) + " " + JSON.parse(RESPONSE__Json_DATA.Data).progress_message_text2));
    } else if (checkSum_price != 0 && checkSum_price >= JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value) {
      var remaining_money_value = JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value - checkSum_price;
      $("#NWS_announcement_message_bar--id").remove();
      $('body').prepend(Shipping_banner('100% !important', 'middle', '6px', 'Arial, sans', '100%', '100%', 'inline-block', 'center', 'rgb(95, 4, 4)', 'white', '0.8em', JSON.parse(RESPONSE__Json_DATA.Data).goal_message_text));
    }
  }
  
}
window.setInterval('SYNC______()', 100);

function Shipping_banner(min_width, vertical_align, padding, font_family, width, height, display, text_align, background, color, font_size, text_message) {
  return `
    <div class="container announcement" style="
    display: `+ display + `;
    height: `+ height + `;
    text-align: `+ text_align + `;
    width: `+ width + `;
    background: `+ background + `;
    color: `+ color + `;
    font-family: `+ font_family + `;
    margin: 0;
    padding: `+ padding + `;
    vertical-align: `+ vertical_align + `;
    font-size: `+ font_size + `;
    min-width: `+ min_width + `;
    min-height: 30px !important;
    " id="NWS_announcement_message_bar--id">
        <div class="row">
            <div class="col-sm-12">
                <div class="announcement_message_bar_text" id="announcement_message_bar_text-id">`+ text_message + `</div>
            </div>
        </div>
    </div>
  `;
}


let snowflakes_count = 200;
// let base_css = ``; // Put your custom base css here
if (typeof total !== 'undefined'){
    snowflakes_count = total;
}
// This function allows you to turn on and off the snow
function toggle_snow() {
    let check_box = document.getElementById("toggle_snow");
    if (check_box.checked == true) {
        document.getElementById('snow').style.display = "block";
    }
    else {
        document.getElementById('snow').style.display = "none";
    }
}
// Creating snowflakes
function spawn_snow(snow_density = 200) {
    snow_density -= 1;

    for (let x = 0; x < snow_density; x++) {
        let board = document.createElement('div');
        board.className = "snowflake";

        document.getElementById('snow').appendChild(board);
    }
}
// Append style for each snowflake to the head
function add_css(rule) {
    let css = document.createElement('style');
    css.type = 'text/css';
    css.appendChild(document.createTextNode(rule)); // Support for the rest
    document.getElementsByTagName("head")[0].appendChild(css);
}
// Math
function random_int(value = 100){
    return Math.floor(Math.random() * value) + 1;
}
function random_range(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
// Create style for snowflake
function spawnSnowCSS(snow_density = 200){
    let snowflake_name = "snowflake";
    let rule = ``;
    if (typeof base_css !== 'undefined'){
        rule = base_css;
    }
    
    for(let i = 1; i < snow_density; i++){
        let random_x = Math.random() * 100; // vw
        let random_offset = random_range(-100000, 100000) * 0.0001; // vw;
        let random_x_end = random_x + random_offset;
        let random_x_end_yoyo = random_x + (random_offset / 2);
        let random_yoyo_time = random_range(30000, 80000) / 100000;
        let random_yoyo_y = random_yoyo_time * 100; // vh
        let random_scale = Math.random();
        let fall_duration = random_range(10, 30) * 1; // s
        let fall_delay = random_int(30) * -1; // s
        let opacity_ = Math.random();

        rule += `
        .${snowflake_name}:nth-child(${i}) {
            opacity: ${opacity_};
            transform: translate(${random_x}vw, -10px) scale(${random_scale});
            animation: fall-${i} ${fall_duration}s ${fall_delay}s linear infinite;
        }

        @keyframes fall-${i} {
            ${random_yoyo_time*100}% {
                transform: translate(${random_x_end}vw, ${random_yoyo_y}vh) scale(${random_scale});
            }

            to {
                transform: translate(${random_x_end_yoyo}vw, 100vh) scale(${random_scale});
            }
            
        }
        `
    }

    add_css(rule);
}
// Load the rules and execute after the DOM loads
window.onload = function() {
    spawnSnowCSS(snowflakes_count);
    spawn_snow(snowflakes_count);
};
// TODO add progress bar for slower clients
