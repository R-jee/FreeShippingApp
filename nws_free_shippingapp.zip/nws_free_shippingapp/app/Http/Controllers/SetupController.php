<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\Models\Shop;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;

class SetupController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function install()
    {
        $app_url =  env('APP_URL', '');
        $shop = $_GET['shop'];
        $api_key = env('SHOPIFY_API_KEY', '');
        $scopes = env('SHOPIFY_APP_SCOPES', 'read_orders,write_orders,read_products,write_products,write_script_tags, read_themes,write_themes,read_product_listings,read_customers,write_customers,read_inventory');
        $redirect_uri = $app_url . "/token";
        // Build install/approval URL to redirect to
        $install_url = "https://" . $shop . "/admin/oauth/authorize?client_id=" . $api_key . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);
        return redirect($install_url);
        // Redirect
    }
    public function token()
    {
        // Set variables for our request
        $api_key = env('SHOPIFY_API_KEY', '');
        $shared_secret = env('SHOPIFY_SECRUT_KEY', '');
        $params = $_GET; // Retrieve all request parameters
        $hmac = $_GET['hmac']; // Retrieve HMAC request parameter
        $params = array_diff_key($params, array('hmac' => '')); // Remove hmac from params
        ksort($params); // Sort params lexographically
        $computed_hmac = hash_hmac('sha256', http_build_query($params), $shared_secret);
        // Use hmac data to check that the response is from Shopify or not
        if (hash_equals($hmac, $computed_hmac)) {

            // Set variables for our request
            $query = array(
                "client_id" => $api_key, // Your API key
                "client_secret" => $shared_secret, // Your app credentials (secret key)
                "code" => $params['code'] // Grab the access key from the URL
            );
            // Generate access token URL
            $access_token_url = "https://" . $params['shop'] . "/admin/oauth/access_token";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $access_token_url);
            curl_setopt($ch, CURLOPT_POST, count($query));
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($query));
            $result = curl_exec($ch);
            curl_close($ch);
            // Store the access token
            $result = json_decode($result, true);
            $access_token = $result['access_token'];
            // Show the access token (don't do this in production!)
            try {
                $shop = new Shop;
                $shop->shop_url = $params['shop'];
                $shop->access_token = $access_token;
                if ($shop->save()) {
                    // var_dump($shop);

                    return redirect("https://" . $params['shop'] . "/admin/apps/freeshippingappnws");
                } else {
                    echo 'Fail to store Access Token...';
                    return "";
                }
            } catch (\Exception $e) {
                echo $e->getMessage();
            }
        } else {
            // Someone is trying to be shady!
            abort(401, 'Unauthorized action.');
            return "";
        }
    }
    public function nwsapp()
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Security-Policy: frame-ancestors *');
        header('X-Frame-Options: ALLOWALL');

        $app_url =  env('APP_URL', '');
?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">

            <link href='https://fonts.googleapis.com/css?family=Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette' rel='stylesheet' type='text/css'>
            <link href='https://fonts.googleapis.com/css?family=Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette' rel='stylesheet' type='text/css'>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="./assets/css/custom_app.css">
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" />
            <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.11.3/af-2.3.7/b-2.0.1/b-colvis-2.0.1/b-html5-2.0.1/b-print-2.0.1/cr-1.5.4/date-1.1.1/fc-4.0.0/fh-3.2.0/kt-2.6.4/r-2.2.9/rg-1.1.3/rr-1.2.8/sc-2.0.5/sb-1.2.2/sp-1.4.0/sl-1.3.3/datatables.min.css" />

            <!-- <link rel="stylesheet" href="./assets/lib/css/emoji.min.css"/> -->
            <link rel="stylesheet" href="https://onesignal.github.io/emoji-picker/lib/css/emoji.css" />

            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/js/bootstrap.bundle.min.js"></script>
            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
            <script type="text/javascript" src="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.11.3/af-2.3.7/b-2.0.1/b-colvis-2.0.1/b-html5-2.0.1/b-print-2.0.1/cr-1.5.4/date-1.1.1/fc-4.0.0/fh-3.2.0/kt-2.6.4/r-2.2.9/rg-1.1.3/rr-1.2.8/sc-2.0.5/sb-1.2.2/sp-1.4.0/sl-1.3.3/datatables.min.js"></script>
            <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
            <!-- <script src="./assets/lib/js/config.min.js"></script> -->
            <!-- <script src="./assets/lib/js/util.min.js"></script> -->
            <!-- <script src="./assets/lib/js/jquery.emojiarea.min.js"></script> -->
            <!-- <script src="./assets/lib/js/emoji-picker.min.js"></script> -->
            <script src="https://onesignal.github.io/emoji-picker/lib/js/config.js"></script>
            <script src="https://onesignal.github.io/emoji-picker/lib/js/util.js"></script>
            <script src="https://onesignal.github.io/emoji-picker/lib/js/jquery.emojiarea.js"></script>
            <script src="https://onesignal.github.io/emoji-picker/lib/js/emoji-picker.js"></script>

            <title>NWS Free Shipping Bar App</title>
        </head>
        <style></style>
        <body class="body" id="body">

            <?php
            $requests = $_GET;
            $hmac = $requests['hmac'];
            $requests = array_diff_key($requests, array('hmac' => '')); // Remove hmac from params
            ksort($requests); // Sort params lexographically
            $computed_hmac = hash_hmac('sha256', http_build_query($requests), env('SHOPIFY_SECRUT_KEY', ''));
            // Use hmac data to check that the response is from Shopify or not
            $serializeArray = serialize($requests);
            $requests = array_diff_key($requests, array('hmac' => ''));
            ksort($requests);
            $shop = $requests['shop'];
            $user0 =  DB::table('freeShippingapp_')->where('shop_url', $shop)->get();
            if ($user0->count() == 0) {
                $app_url =  env('APP_URL', '');
                $redirect_uri = $app_url . "/install?shop=" . $shop;
                return redirect($redirect_uri);
            } else {

                (hash_equals($hmac, $computed_hmac)) ? 'true' : abort(401, 'there is no access please reinstall app.');
                $chkProduct2 = DB::table('freeShippingapp_')->where('shop_url', $shop)->count();
                if ($chkProduct2 == 0) {
                    abort(401, 'there is no access please reinstall app.');
                }
                $chkProduct = DB::table('freeShippingapp_')->where('shop_url', $shop)->first();
                $result = (array) $chkProduct;
                $shop = $result['shop_url'];
                $token = $result['access_token'];
                $this->webhooks($token, $this->Get_host_shop($shop), env('APP_URL', ''), "2021-10");
            }

            
            $chkProduct = DB::table('freeShippingapp_')->where('shop_url', $shop)->first();
            $result = (array) $chkProduct;
            $shop = $result['shop_url'];
            $token = $result['access_token'];
            ///////////////////////////////////////////////     script tag
            $this->ScriptTags__callFunctions( $token , $shop , "2021-10");
            ///////////////////////////////////////////////

            $GOT_Form_data_ = $result['data'];
            $GOT_Form_data_ARRAY = json_decode( $GOT_Form_data_ , true);
            
            $currency__ = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/shop.json", array(), 'GET');
            $currency__ = json_decode($currency__['response'], JSON_PRETTY_PRINT);


            $message_text = (isset( $GOT_Form_data_ARRAY['message_text'] )) ? $GOT_Form_data_ARRAY['message_text'] : "";
            $message_value = (isset( $GOT_Form_data_ARRAY['message_value'] )) ? $GOT_Form_data_ARRAY['message_value'] : "";
            $progress_message_text1 = (isset( $GOT_Form_data_ARRAY['progress_message_text1'] )) ? $GOT_Form_data_ARRAY['progress_message_text1'] : "";
            $progress_message_value = (isset( $GOT_Form_data_ARRAY['progress_message_value'] )) ? $GOT_Form_data_ARRAY['progress_message_value'] : "";
            $progress_message_text2 = (isset( $GOT_Form_data_ARRAY['progress_message_text2'] )) ? $GOT_Form_data_ARRAY['progress_message_text2'] : "";
            $goal_message_text = (isset( $GOT_Form_data_ARRAY['goal_message_text'] )) ? $GOT_Form_data_ARRAY['goal_message_text'] : "";
            $currency_ = (isset( $GOT_Form_data_ARRAY['currency_'] )) ? $GOT_Form_data_ARRAY['currency_'] : "";


            // print_r($currency__['shop']['currency']);

            $Active_theme_ID = '';
            $Active_theme_NAME = '';

            $theme = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes.json", array(), 'GET');
            $theme = json_decode($theme['response'], JSON_PRETTY_PRINT);

            foreach ($theme as $theme_key => $theme_) {
                foreach ($theme_ as $theme_key_ => $theme_value) {
                    if($theme_value['role'] == "main"){
                        $Active_theme_ID = $theme_value['id'];
                        $Active_theme_NAME = $theme_value['name'];
                    }
                }
            }

            DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('active_theme_id' => $Active_theme_ID )
            );

            $array = array(
                "asset" => array(
                    "key" => "layout/theme.liquid"
                )
            );
            $assets = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/". $Active_theme_ID ."/assets.json", $array, 'GET');
            $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
            // print_r($assets['asset']['value']);
            // print_r( htmlentities( $assets['asset']['value'] ));
            // echo strpos( htmlentities( $assets['asset']['value'] ) , "{% include 'Shipping_bar_snippet' %}" );

            $theme_liquid_file_Data = $assets['asset']['value'];
            $snippet_file_name = "{% include 'Shipping_bar_snippet' %}";
            $head_tag = '</head>';
            $new_head_tag = $head_tag . $snippet_file_name;
            $new_theme_liquid_file_Data = str_replace($head_tag , $new_head_tag , $theme_liquid_file_Data );

            $OUTPUT_theme_liquid__ = "";
            if( strpos($assets['asset']['value'] , $snippet_file_name ) === false ){
                $array = array(
                    "asset" => array(
                        "key" => "layout/theme.liquid",
                        "value" => $new_theme_liquid_file_Data
                    )
                );
                $assets = $this->shopify_call($token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/". $Active_theme_ID ."/assets.json", $array, 'PUT');
                $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
                // print_r($assets['asset']['value']);
                $OUTPUT_theme_liquid__ = $assets;
            }
            // print_r($OUTPUT_theme_liquid__);
            /////////////////////////////////////////////   Put  snippets --  Creating  countdown-bar.liquid in Store....
            $array = array(
                'asset' => array(
                    "key" => "snippets/Shipping_bar_snippet.liquid",
                    "value" => '
                    <style> 
                        .snowflake {
                            position: absolute;
                            width: 10px;
                            height: 10px;
                            background: linear-gradient(white, white);
                            border-radius: 50%;
                            filter: drop-shadow(0 0 10px white);
                        } 
                    </style>
                    <script defer >'. file_get_contents( getcwd() . "/Shipping_bar_snippet.txt") .'</script>'
                )
            );
            $Put_selectedTheme_Assets = $this->shopify_call($token, $this->Get_host_shop($shop) , "/admin/api/2021-10/themes/" . $Active_theme_ID . " /assets.json", $array, 'PUT');
            $Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
            // print_r($Put_selectedTheme_Assets);


            ?>
            <section>
                <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">

                            <ul class="nav  bg-dark  mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link custom-btn " id="nav-Home-tab" data-bs-toggle="tab" data-bs-target="#nav-Home" type="button" role="tab" aria-controls="nav-Home" aria-selected="false">
                                        <img src="./assets/icons/icon-1.png" class="img-fluid img-thumbnail bg-dark" style="height:60px; padding: 0rem;border: 0px solid transparent;" alt="" id="Home-Window"></button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link custom-btn" id="nav-settings-tab" data-bs-toggle="tab" data-bs-target="#nav-settings" type="button" role="tab" aria-controls="nav-settings" aria-selected="false">Settings</button>
                                </li>
                                <li class="nav-item nav-item_helpguides" role="presentation">
                                    <button class="nav-link custom-btn" id="nav-helpguides-tab" data-bs-toggle="tab" data-bs-target="#nav-helpguides" type="button" role="tab" aria-controls="nav-helpguides" aria-selected="false">Helpguides</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link custom-btn" id="nav-subscriptions_pricing-tab" data-bs-toggle="modal" data-bs-target="#pricing_plan_Modal" type="button" role="tab" aria-controls="nav-subscriptions_pricing" aria-selected="false">Subscriptions & Pricing page</button>
                                </li>
                            </ul>
                            <span><img src="./assets/icons/external-link-alt-solid.png" class="img-fluid img-thumbnail  bg-dark" style="height:34px; padding: 0rem;border: 0px solid transparent;" alt="" id="redirect-to-newWindow"></span>
                        </div>
                    </div>
                </nav>

                <section class="app_body_" id="app_body_">

                    <div class="tab-content" id="pills-tabContent">
                        <!-- // ---------------------------------------------------------------------------------------------------------- -->
                        <div class="tab-pane fade" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings-tab">
                            <!-- //     Settings   tags  -->
                            <div class="settings_tab_container container">
                                // Settings

                            </div>
                        </div>
                        <!-- // ---------------------------------------------------------------------------------------------------------- -->
                        <div class="tab-pane fade" id="nav-helpguides" role="tabpanel" aria-labelledby="nav-helpguides-tab">
                            <div class="helpguides_tab_container container">
                                // Helplines

                            </div>
                        </div>
                        <div class="tab-pane fade active show" id="nav-Home" role="tabpanel" aria-labelledby="nav-Home-tab">
                            <div class="Home_tab_container container">

                                <div class="card content_card__" id="content_card__">
                                    <h5 class="card-header">Content</h5>
                                    <div class="card-body">
                                        <section class="container content-free-shipping" id="content-free-shipping_id">

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h6>Message:</h6>
                                                </div>
                                                <div class="col-sm-12 col-md-9">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text"  data-emojiable="true" class="form-control form-control-sm content_message_text" id="content_message_text_id" placeholder="Get Free Shipping When buying over"  <?php echo ($message_text != "") ? 'value="'.$message_text.'"' : 'value="Get Free Shipping When buying over"'; ?>  >
                                                        <label for="content_message_text_id">Message Text</label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-3">
                                                    <div class="input-group_price mb-3">
                                                        <span class="input-group-text" id="content_message_value_currency_id"><?php echo ($currency__['shop']['currency'] != "") ? $currency__['shop']['currency'] : '$'; ?></span>
                                                        <div class="form-floating content_message_value_div">
                                                            <input type="text" class="form-control form-control-sm content_message_value" id="content_message_value_id" placeholder="100" <?php echo ($message_value != "") ? 'value="'.$message_value.'"' : 'value="100"'; ?> >
                                                            <label for="content_message_value_id">Value</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h6>Progress Message:</h6>
                                                    <?php // echo json_decode('"\ud83d\ude0d\ud83d\udc4dGet Free Shipping When buying over"'); ?>

                                                </div>
                                                <div class="col-sm-12 col-md-4">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" data-emoji-input="unicode" data-emojiable="true" class="form-control form-control-sm content_progress_message_text1" id="content_progress_message_text1_id" placeholder="Only" <?php echo ($progress_message_text1 != "") ? 'value="'.$progress_message_text1.'"' : 'value="Only"'; ?>>
                                                        <label for="content_progress_message_text1_id">Progress Message Text first</label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-3">
                                                    
                                                    <div class="input-group_price mb-3">
                                                        <span class="input-group-text" id="content_message_value_currency_id"><?php echo ($currency__['shop']['currency'] != "") ? $currency__['shop']['currency'] : '$'; ?></span>
                                                        <div class="form-floating content_message_value_div">
                                                            <input type="text" class="form-control form-control-sm content_progress_message_value" id="content_progress_message_value_id" placeholder="100" <?php echo ($progress_message_value != "") ? 'value="'.$progress_message_value.'"' : 'value="100"'; ?>>
                                                            <label for="content_progress_message_value_id">Value</label>
                                                        </div> 
                                                    </div>
                                                    
                                                </div>
                                                <div class="col-sm-12 col-md-5">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" data-emoji-input="unicode" data-emojiable="true" class="form-control form-control-sm content_progress_message_text2" id="content_progress_message_text2_id" placeholder="Left to Get Free Shipping!" <?php echo ($progress_message_text2 != "") ? 'value="'.$progress_message_text2.'"' : 'value="Left to Get Free Shipping!"'; ?>>
                                                        <label for="content_progress_message_text2_id">Progress Message Text last</label>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h6>Once Goal Achieved:</h6>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-floating form-floating-sm mb-3">
                                                        <input type="text" data-emoji-input="unicode" data-emojiable="true" class="form-control form-control-sm content_goal_message_text" id="content_goal_message_text_id" placeholder="You made it!! Checkout & Get Free Shipping!" <?php echo ($goal_message_text != "") ? 'value="'.$goal_message_text.'"' : 'value="You made it!! Checkout & Get Free Shipping!"'; ?> >
                                                        <label for="content_goal_message_text_id">Goal achieved Message Text</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">

                                                </div>
                                            </div>


                                        </section>
                                    </div>
                                </div>
                                <!-- ///////////////////////////////////////////////////////////////////////////////// -->

                                <div class="card save_preview_card" id="save_preview_card_id">

                                    <h5 class="card-header">Preview
                                        <button type="submit" class="btn btn-primary save_preview_btn" id="save_preview_btn_id">Submit</button>
                                    </h5>
                                    <nav>
                                        <div class="nav nav-tabs" id="nav_tab_preview_output_id" role="tablist">
                                            <button class="nav-link active" id="nav-message-tab" data-bs-toggle="tab" data-bs-target="#nav-message" type="button" role="tab" aria-controls="nav-message" aria-selected="true">Message</button>
                                            <button class="nav-link" id="nav-message-progress-tab" data-bs-toggle="tab" data-bs-target="#nav-message-progress" type="button" role="tab" aria-controls="nav-message-progress" aria-selected="false">Progress Message</button>
                                            <button class="nav-link" id="nav-message-goal-tab" data-bs-toggle="tab" data-bs-target="#nav-message-goal" type="button" role="tab" aria-controls="nav-message-goal" aria-selected="false">Goal Message</button>
                                        </div>
                                    </nav>

                                    <div class="card-body card-announcement-preview">
                                        <div class="container preview_output_" id="preview_output_id">
                                            <div class="row">
                                                <div class="col-sm-12 preview_output_Div" id="preview_output_Div_id">

                                                    <div class="tab-content" id="nav-tabContent">
                                                        <div class="tab-pane fade show active" id="nav-message" role="tabpanel" aria-labelledby="nav-message-tab">
                                                            <div class="container announcement" id="announcement_message_bar">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="announcement_message_bar_text" id="announcement_message_bar_text-id"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="nav-message-progress" role="tabpanel" aria-labelledby="nav-message-progress-tab">
                                                            <div class="container announcement" id="announcement_progress_message_bar">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="announcement_progress_message_bar_text" id="announcement_progress_message_bar_text-id"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="nav-message-goal" role="tabpanel" aria-labelledby="nav-message-goal-tab">
                                                            <div class="container announcement" id="announcement_goal_message_bar">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="announcement_goal_message_bar_text" id="announcement_goal_message_bar_text-id"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ///////////////////////////////////////////////////////////////////////////////// -->

                            </div>
                            <!--  Home container end   ////////// -->
                        </div>
                        <!--  Home Tab end   ////////// -->

                    </div>
                </section>

            </section>


            <script>
                $(function() {
                    // Initializes and creates emoji set from sprite sheet
                    window.emojiPicker = new EmojiPicker({
                        emojiable_selector: '[data-emojiable=true]',
                        assetsPath: 'http://onesignal.github.io/emoji-picker/lib/img/',
                        popupButtonClasses: 'fa fa-smile-o'
                    });
                    // Finds all elements with `emojiable_selector` and converts them to rich emoji input fields
                    // You may want to delay this step if you have dynamically created input fields that appear later in the loading process
                    // It can be called as many times as necessary; previously converted input fields will not be converted again
                    window.emojiPicker.discover();
                });

                document.getElementById('announcement_message_bar_text-id').innerText = $('#content_message_text_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_message_value_id').val();
                document.getElementById('announcement_progress_message_bar_text-id').innerText = $('#content_progress_message_text1_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_progress_message_value_id').val() + " " + $('#content_progress_message_text2_id').val();
                document.getElementById('announcement_goal_message_bar_text-id').innerText = $('#content_goal_message_text_id').val();

                $("#save_preview_btn_id").on("click", function() {
                    $.ajax({
                        type: "POST",
                        url: '<?php echo route('save_message_data_'); ?>',
                        data: {
                            fetch_shop__ : "<?php echo $shop; ?>",
                            currency_ : $('#content_message_value_currency_id').text(),
                            message_text : $('#content_message_text_id').val(),
                            message_value : $('#content_message_value_id').val(),
                            progress_message_text1 : $('#content_progress_message_text1_id').val(),
                            progress_message_value : $('#content_progress_message_value_id').val(),
                            progress_message_text2 : $('#content_progress_message_text2_id').val(),
                            goal_message_text : $('#content_goal_message_text_id').val(),
                        },
                        success: function(data) {
                            // console.log(JSON.parse(data));
                            location.reload();
                        },
                        error: function(data) {
                        }
                    }); // ----  end  ajax
                });
                function get_message_bar_text() {
                    $('#content_message_text_id').change('input', function() {
                        document.getElementById('announcement_message_bar_text-id').innerText = $('#content_message_text_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_message_value_id').val();
                    });
                    $('#content_message_value_id').change('input', function() {
                        document.getElementById('announcement_message_bar_text-id').innerText = $('#content_message_text_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_message_value_id').val();
                    });
                }
                window.setInterval('get_message_bar_text()', 500);
                function get_progress_message_bar_text() {
                    $('#content_progress_message_text1_id').change('input', function() {
                        document.getElementById('announcement_progress_message_bar_text-id').innerText = $('#content_progress_message_text1_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_progress_message_value_id').val() + " " + $('#content_progress_message_text2_id').val();
                    });
                    $('#content_progress_message_value_id').change('input', function() {
                        document.getElementById('announcement_progress_message_bar_text-id').innerText = $('#content_progress_message_text1_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_progress_message_value_id').val() + " " + $('#content_progress_message_text2_id').val();
                    });
                    $('#content_progress_message_text2_id').change('input', function() {
                        document.getElementById('announcement_progress_message_bar_text-id').innerText = $('#content_progress_message_text1_id').val() + " " + $('#content_message_value_currency_id').text() + $('#content_progress_message_value_id').val() + " " + $('#content_progress_message_text2_id').val();
                    });
                }
                window.setInterval('get_progress_message_bar_text()', 500);
                function get_goal_message_bar_text() {
                    $('#content_goal_message_text_id').change('input', function() {
                        document.getElementById('announcement_goal_message_bar_text-id').innerText = $('#content_goal_message_text_id').val();
                    });
                }
                window.setInterval('get_goal_message_bar_text()', 500);


            </script>
        </body>

        </html>
<?php
    }

    public function uninstallApp()
    {
        $response = '';
        $hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
        $shop_Domain = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
        $topic_header = $_SERVER['HTTP_X_SHOPIFY_TOPIC'];
        $data = file_get_contents('php://input');
        $utf8 = utf8_encode($data);
        $data_json = json_decode($utf8, true);
        $SHOPIFY_SECRUT_KEY = env('SHOPIFY_SECRUT_KEY', '');
        $verified = $this->verify_webhook($data, $hmac_header, $SHOPIFY_SECRUT_KEY);
        $chkProduct = DB::table('freeShippingapp_')->where('shop_url', $shop_Domain)->first();
        $user = (array) $chkProduct;
        $access_token = $user['access_token'];
        $Active_theme_ID =  $user['active_theme_id'];
        $shop = $shop_Domain;

        if( $verified == true ) {
            if( $topic_header == 'app/uninstalled' || $topic_header == 'shop/update') {
                if ($topic_header == 'app/uninstalled') {
                    // $array = array(
                    //     'asset' => array(
                    //         "key" => "snippets/Shipping_bar_snippet.liquid"
                    //     )
                    // );
                    // $Delete_snippet_file = $this->shopify_call($access_token, $this->Get_host_shop($shop) , "/admin/api/2021-10/themes/" . $Active_theme_ID . " /assets.json", $array, "DELETE");
                    // $Delete_snippet_file = json_decode($Delete_snippet_file['response'], JSON_PRETTY_PRINT);

                    // $theme = $this->shopify_call($access_token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes.json", array(), 'GET');
                    // $theme = json_decode($theme['response'], JSON_PRETTY_PRINT);

                    // foreach ($theme as $theme_key => $theme_) {
                    //     foreach ($theme_ as $theme_key_ => $theme_value) {
                    //         if($theme_value['role'] == "main"){
                    //             $Active_theme_ID = $theme_value['id'];
                    //             $Active_theme_NAME = $theme_value['name'];
                    //         }
                    //     }
                    // }
                    // $array = array(
                    //     "asset" => array(
                    //         "key" => "layout/theme.liquid"
                    //     )
                    // );
                    // $assets = $this->shopify_call($access_token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/". $Active_theme_ID ."/assets.json", $array, 'GET');
                    // $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
                    // // echo strpos( htmlentities( $assets['asset']['value'] ) , "{% include 'Shipping_bar_snippet' %}" );
                    // if( strpos( htmlentities( $assets['asset']['value'] ) , "{% include 'Shipping_bar_snippet' %}" ) !== false ){
                    //     $Delete_snippet_tag_from_liquid_file = str_replace("{% include 'Shipping_bar_snippet' %}", '', htmlentities( $assets['asset']['value'] ) );
                    //     $array = array(
                    //         "asset" => array(
                    //             "key" => "layout/theme.liquid",
                    //             "value" => $Delete_snippet_tag_from_liquid_file
                    //         )
                    //     );
                    //     $assets = $this->shopify_call($access_token, $this->Get_host_shop($shop), "/admin/api/2021-10/themes/". $Active_theme_ID ."/assets.json", $array, 'PUT');
                    //     $assets = json_decode($assets['response'], JSON_PRETTY_PRINT);
                    DB::table('freeShippingapp_')->where('shop_url', $shop_Domain)->delete();
                    $response =  $data_json;
                } else {
                    $response = 'This Request is not from shopify verified merchant...';
                }
            }
        }

        $log = fopen($shop_Domain . "_uninstalled.json", "a") or die("Can not open or create this file.");
        if (file_exists($shop_Domain . "_uninstalled.json")) {
            fputs($log, PHP_EOL . $shop_Domain . " TOKEN ::  " . $access_token . " SHOP ::  " . $shop_Domain . ' is successfully deleted from the database.'  . PHP_EOL . json_encode($response));
        } else {
            fputs($log, json_encode($response));
        }
        fclose($log);
        return "";
    }
    public function createProductHook()
    {
        echo "";
    }
    public function createCartHook()
    {
    }
    public function updateCartHook()
    {

    }



    public function upgrade_Basic()
    {
        # code...
    }
    public function upgrade_Pro()
    {
        # code...
    }

    public function shopify_call($token, $shop, $api_endpoint, $query = array(), $method = 'GET', $request_headers = array())
    {
        // Build URL
        //	$url = "https://" . $shop . ".myshopify.com" . $api_endpoint;
        $url = "https://" . $shop . ".myshopify.com" . $api_endpoint;
        if (!is_null($query) && in_array($method, array('GET',     'DELETE'))) $url = $url . "?" . http_build_query($query);
        // Configure cURL
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, TRUE);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 3);
        // curl_setopt($curl, CURLOPT_SSLVERSION, 3);
        curl_setopt($curl, CURLOPT_USERAGENT, 'My New Shopify App v.1');
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        // Setup headers
        $request_headers[] = "";
        if (!is_null($token)) $request_headers[] = "X-Shopify-Access-Token: " . $token;
        curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);
        if ($method != 'GET' && in_array($method, array('POST', 'PUT'))) {
            if (is_array($query)) $query = http_build_query($query);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $query);
        }
        // Send request to Shopify and capture any errors
        $response = curl_exec($curl);
        $error_number = curl_errno($curl);
        $error_message = curl_error($curl);
        // Close cURL to be nice
        curl_close($curl);
        // Return an error is cURL has a problem
        if ($error_number) {
            return $error_message;
        } else {
            // No error, return Shopify's response by parsing out the body and the headers
            $response = preg_split("/\r\n\r\n|\n\n|\r\r/", $response, 2);
            // Convert headers into an array
            $headers = array();
            $header_data = explode("\n", $response[0]);
            $headers['status'] = $header_data[0]; // Does not contain a key, have to explicitly set
            array_shift($header_data); // Remove status, we've already set it above
            foreach ($header_data as $part) {
                $h = explode(":", $part);
                $headers[trim($h[0])] = trim($h[1]);
            }
            // Return headers and Shopify's response
            return array('headers' => $headers, 'response' => $response[1]);
        }
    }

    public function Get_host_shop($shop)
    {
        $url = parse_url('https://' . $shop);
        $host = explode('.', $url['host']);
        $host_shop = $host[0];
        return $host_shop;
    }
    public function verify_webhook($data, $hmac_header, $SHOPIFY_SECRUT_KEY)
    {
        $calculated_hmac = base64_encode(hash_hmac('sha256', $data, $SHOPIFY_SECRUT_KEY, true));
        return hash_equals($hmac_header, $calculated_hmac);
    }
    function webhooks($access_token, $host_shop, $app_url, $version)
    {
        $array = array(
            "webhook" => array(
                "topic"   => "app/uninstalled",
                "address" => route('uninstalled_'),
                "format"  => "json"
            )
        );
        $this->shopify_call($access_token, $host_shop, "/admin/api/" . $version . "/webhooks.json", $array, 'POST');
        // $Uninstall = json_decode($Uninstall['response'], JSON_PRETTY_PRINT);
        // print_r($Uninstall);

        $array = array(
            "webhook" => array("topic" => "products/create",
                "address" =>  route('createProductHook_'),
                "format"  => "json"
            )
        );
        $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');
        
        $array = array(
            "webhook" => array("topic"   => "carts/create",
                "address" =>  route('createCartHook_'),
                "format"  => "json"
            )
        );
        $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');
        
        $array = array(
            "webhook" => array("topic"   => "carts/update",
                "address" =>  route('updateCartHook_'),
                "format"  => "json"
            )
        );
        $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');
        
        // $array = array(
        //     "webhook" => array("topic"   => "products/update",
        //         "address" =>  route('updateProductHook_'),
        //         "format"  => "json"
        //     )
        // );
        // $this->shopify_call($access_token, $host_shop, "/admin/api/". $version ."/webhooks.json", $array, 'POST');
    }

    function ScriptTags__callFunctions( $token , $shop , $version){

        $host_shop = $this->Get_host_shop($shop);
        $script_tag_count = $this->shopify_call($token, $host_shop, "/admin/api/". $version ."/script_tags/count.json", array(), 'GET');
        $script_tag_count = json_decode($script_tag_count['response'], JSON_PRETTY_PRINT);
        //  print_r($script_tag);
        $script_tag = $this->shopify_call($token, $host_shop, "/admin/api/". $version ."/script_tags.json", array(), 'GET');
        $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
        // print_r($script_tag);
        if ($script_tag_count['count'] < 1) {
            $script_array = array(
                'script_tag' => array(
                    'event' => 'onload',
                    'src' => env('APP_URL','') .'/custom_script.js'
                )
            );
            $script_tag =  $this->shopify_call($token, $host_shop, "/admin/api/". $version ."/script_tags.json", $script_array, 'POST');
            $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
            $script_tag_id = $script_tag['script_tag']['id'];

            // $statement = $pdo->prepare("UPDATE `manage_discounts` SET `script_tag_id`= '" . $script_tag_id . "'  WHERE `shop_url` = '" . $shop . "' ");
            // $statement->execute();
            $check = DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('script_tag_id' => $script_tag_id )
            ); 
        } else if ($script_tag_count['count'] == 1) {
            $delete_script_tag =  $this->shopify_call($token, $host_shop, "/admin/api/". $version ."/script_tags/" . $script_tag['script_tags'][0]['id'] . ".json", array(), 'DELETE');
            $delete_script_tag = json_decode($delete_script_tag['response'], JSON_PRETTY_PRINT);
            $script_array = array(
                'script_tag' => array(
                    'event' => 'onload',
                    'src' => env('APP_URL','') .'/custom_script.js'
                )
            );
            $script_tag =  $this->shopify_call($token, $host_shop, "/admin/api/". $version ."/script_tags.json", $script_array, 'POST');
            $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
            $script_tag_id = $script_tag['script_tag']['id'];
            
            $check = DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('script_tag_id' => $script_tag_id )
            ); 
        }
    }


}
?>
