<?php
namespace App\Http\Controllers;
use DOMDocument;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\Models\Shop;
use Illuminate\Support\Env;

class AjaxController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function save_message_data(){
        if (isset($_POST['fetch_shop__']) ) {
            $shop = $_POST['fetch_shop__'];
            $data_array = array(
                'message_text' => $_POST['message_text'],
                'message_value' => $_POST['message_value'],
                'progress_message_text1' => $_POST['progress_message_text1'],
                'progress_message_value' => $_POST['progress_message_value'],
                'progress_message_text2' => $_POST['progress_message_text2'],
                'goal_message_text' => $_POST['goal_message_text'],
                'currency_' => $_POST['currency_'],
            );
            $check = DB::table('freeShippingapp_')->where('shop_url', $shop)->update(
                array('data' => json_encode($data_array) )
            ); 
            if($check == true){
                echo 'Success';
            }
        } else {
            echo ('ERROR!');
        }
    }

    public function Ajax_get_messages_Data()
    {
        header('Access-Control-Allow-Origin: *');
        // header("Content-Security-Policy: frame-ancestors https://*.myshopify.com *.shopifycloud.com *.shopifysvc.com *.amazon.com *.paypal.com *.facebook.com sessions.bugsnag.com analytics.tiktok.com bat.bing.com www.google-analytics.com ct.pinterest.com stats.g.doubleclick.net");
        header('Content-Security-Policy: frame-ancestors https://*.myshopify.com');
        
        if (isset($_GET['get_check']) && isset($_GET['shop']) ) {

            $DATA_ARRAY = (array) DB::table('freeShippingapp_')->where('shop_url', $_GET['shop'] )->first();
            if( count($DATA_ARRAY) == 0 ){ 
                die ('{"Status" : "Error!", "Data" : "{}"}');
            }
            echo '{"Status" : "true", "Data" : '. json_encode($DATA_ARRAY['data']) .'}';
        }else{
            echo '{"Status" : "Error!", "Data" : "{}"}';
        }
    }

    
}