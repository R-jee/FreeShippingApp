<?php 

$string = file_get_contents("./channelfeeds_api.json");
echo $string;

?>