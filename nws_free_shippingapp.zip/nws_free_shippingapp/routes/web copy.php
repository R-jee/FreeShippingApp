<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    //   echo route('uninstalled');
    //   return "";
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/install', [App\Http\Controllers\SetupController::class, 'install'])->name('installApp');
Route::get('/token', [App\Http\Controllers\SetupController::class, 'token'])->name('gettoken');
Route::get('/apphome', [App\Http\Controllers\SetupController::class, 'feedmosterapp'])->name('feedmosterapphome');

Route::get('/upgrade_Basic', [App\Http\Controllers\SetupController::class, 'upgrade_Basic'])->name('upgradeBasicPlan');
Route::get('/upgrade_Pro', [App\Http\Controllers\SetupController::class, 'upgrade_Pro'])->name('upgradeProPlan');

//  -----------------   HOOKS  ROUTES 
Route::post('/uninstall-app', [App\Http\Controllers\SetupController::class,'uninstallApp'])->name("uninstalled");
Route::post('/create-producthook', [App\Http\Controllers\SetupController::class,'createProductHook'])->name("createProductHook_");
Route::post('/update-producthook', [App\Http\Controllers\SetupController::class,'updateProductHook'])->name("updateProductHook_");
Route::post('/delete-producthook', [App\Http\Controllers\SetupController::class,'deleteProductHook'])->name("deleteProductHook_");
Route::post('/fulfill-orderhook', [App\Http\Controllers\SetupController::class,'fulfillOrderHook'])->name("fulfillOrderHook_");
Route::post('/create-orderhook', [App\Http\Controllers\SetupController::class,'createOrderHook'])->name("createOrderHook_");
Route::post('/paid-orderhook', [App\Http\Controllers\SetupController::class,'paidOrderHook'])->name("paidOrderHook_");
Route::post('/cancel-orderhook', [App\Http\Controllers\SetupController::class,'cancelOrderHook'])->name("cancelOrderHook_");
//  -----------------   HOOKS  ROUTES 

//  -----------------   AJAX ROUTES  
Route::post('/ajex-fetch-category-against-parent-id', [App\Http\Controllers\AjaxController::class,'Ajex_fetch_category_against_parent_id'])->name("Ajex_fetch_category_against_parent_id_");
Route::post('/Ajex-fetch-Subcategory-counts', [App\Http\Controllers\AjaxController::class,'Ajex_fetch_Subcategory_counts'])->name("Ajex_fetch_Subcategory_counts_");

Route::post('/Ajex-delete-feeds_url', [App\Http\Controllers\AjaxController::class,'Ajex_delete__feeds_url___'])->name("Ajex_delete__feeds_url___name_");
Route::post('/Ajex-search-texanomy-against-str-text', [App\Http\Controllers\AjaxController::class,'Ajex_search_texanomy_against_str_text'])->name("Ajex_search_texanomy_against_str_text_");

Route::post('/Ajex-reimportProducts', [App\Http\Controllers\AjaxController::class,'Ajex_reimportProducts'])->name("Ajex_reimportProducts_");
Route::post('/channelfeeds-api', [App\Http\Controllers\AjaxController::class,'channelfeeds_api'])->name("channelfeeds_api_");

Route::post('/Ajax-create-csv', [App\Http\Controllers\AjaxController::class,'Ajax_create__csv'])->name("Ajax_create__csv_");
Route::post('/Ajax-create-csv-filter', [App\Http\Controllers\AjaxController::class,'Ajax_create__csv_filter'])->name("Ajax_create__csv_filter_");

//  -----------------   AJAX ROUTES  
