
var scriptFilename = "custom_script.js"; // don't forget to set the filename
var scriptUrl = (function () {
  if (document.currentScript) {
    // support defer & async (mozilla only)
    return document.currentScript.src;
  } else {
    var ls, s;
    var getSrc = function (ls, attr) {
      var i,
        l = ls.length,
        nf,
        s;
      for (i = 0; i < l; i++) {
        s = null;
        if (ls[i].getAttribute.length !== undefined) {
          s = ls[i].getAttribute(attr, 2);
        }
        if (!s) continue; // tag with no src
        nf = s;
        nf = nf.split("?")[0].split("/").pop(); // get script filename
        if (nf === scriptFilename) {
          return s;
        }
      }
    };
    ls = document.getElementsByTagName("script");
    s = getSrc(ls, "src");
    if (!s) {
      // search reference of script loaded by jQuery.getScript() in meta[name=srcipt][content=url]
      ls = document.getElementsByTagName("meta");
      s = getSrc(ls, "content");
    }
    if (s) return s;
  }
  return "";
})();

var shopPath = scriptUrl; //.substring(0, scriptUrl.lastIndexOf('/'))+"/";
// var App_DomainURL = scriptUrl.split(scriptFilename)[0];
var scriptPath = shopPath.substring(0, scriptUrl.lastIndexOf("/")) + "/";
shopPath = shopPath.split("?");
shopPath = shopPath[1];
shopPath = shopPath.split("=");
shopPath = shopPath[1];

var CHECK_IF_APP_IS_INSTALLED_ON_SHOP = '';

function check_if_app_installed() {
  var xhttp = new XMLHttpRequest();
  xhttp.open("GET", scriptPath + "ajax-get-app-installed-check?shop=" + shopPath + "&get_check=1", true);
  // xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + shopPath + "&get_check=1", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      // console.log( JSON.parse(this.response) );
      // RESPONSE__Json_DATA = JSON.parse(this.response);
      localStorage.setItem("ajax_get_app_installed_check___________", this.response);
    }
  };
  xhttp.send();
}

// CHECK_IF_APP_IS_INSTALLED_ON_SHOP = localStorage.getItem("ajax_get_app_installed_check___________");
// ( JSON.parse( localStorage.getItem("ajax_get_app_installed_check___________") ).App_script == 'true' )
check_if_app_installed();

// var ajax_get_app_installed_check___________ = JSON.parse(localStorage.getItem("ajax_get_app_installed_check___________")).App_script;


// var checkSum_price = 0;
// function cartUpdated_____() {
//   jQuery.ajax({
//     url: '/cart.js',
//     type: "GET",
//     dataType: "json",
//     success: function (data) {
//       checkSum_price = data.total_price / 100;
//     },
//     error: function (data) {
//     },
//   });
// }
// window.setInterval('cartUpdated_____()', 400);

// var shopPath = scriptUrl; //.substring(0, scriptUrl.lastIndexOf('/'))+"/";
// // var App_DomainURL = scriptUrl.split(scriptFilename)[0];
// var scriptPath = shopPath.substring(0, scriptUrl.lastIndexOf("/")) + "/";
// shopPath = shopPath.split("?");
// shopPath = shopPath[1];
// shopPath = shopPath.split("=");
// shopPath = shopPath[1];
// // console.log(shopPath);
// // console.log(scriptPath);

// var RESPONSE__Json_DATA = '';


// function SYNC_BAR____function() {
//   var xhttp = new XMLHttpRequest();
//   // xhttp.open("GET", scriptPath + "ajax-get-messages-data?shop=" + shopPath + "&get_check=1", true);
//   // xhttp.open("GET", "https://promotionking.info/NWS/nws_free_shippingapp/" + "ajax-get-messages-data?shop=" + shopPath + "&get_check=1", true);
//   xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//   xhttp.onreadystatechange = function () {
//     if (this.readyState == 4 && this.status == 200) {
//       // console.log( JSON.parse(this.response) );
//       // RESPONSE__Json_DATA = JSON.parse(this.response);
//       localStorage.setItem("RESPONSE__Json_DATA", this.response);
//     }
//   };
//   xhttp.send();
// }
// SYNC_BAR____function();


// RESPONSE__Json_DATA = JSON.parse(localStorage.getItem("RESPONSE__Json_DATA"));

// function SYNC______() {
//   if (checkSum_price == 0) {
//     $("#NWS_announcement_message_bar--id").remove();
//     $('body').prepend(Shipping_banner('100% !important', 'middle', '6px', 'Arial, sans', '100%', '100%', 'inline-block', 'center', 'rgb(95, 4, 4)', 'white', '0.8em', JSON.parse(RESPONSE__Json_DATA.Data).message_text + " " + JSON.parse(RESPONSE__Json_DATA.Data).currency_ + " " + JSON.parse(RESPONSE__Json_DATA.Data).message_value));
//   } else if (checkSum_price != 0 && checkSum_price < JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value) {
//     var remaining_money_value = JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value - checkSum_price;
//     $("#NWS_announcement_message_bar--id").remove();
//     $('body').prepend(Shipping_banner('100% !important', 'middle', '6px', 'Arial, sans', '100%', '100%', 'inline-block', 'center', 'rgb(95, 4, 4)', 'white', '0.8em', JSON.parse(RESPONSE__Json_DATA.Data).progress_message_text1 + " " + JSON.parse(RESPONSE__Json_DATA.Data).currency_ + " " + remaining_money_value.toFixed(2) + " " + JSON.parse(RESPONSE__Json_DATA.Data).progress_message_text2));
//   } else if (checkSum_price != 0 && checkSum_price >= JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value) {
//     var remaining_money_value = JSON.parse(RESPONSE__Json_DATA.Data).progress_message_value - checkSum_price;
//     $("#NWS_announcement_message_bar--id").remove();
//     $('body').prepend(Shipping_banner('100% !important', 'middle', '6px', 'Arial, sans', '100%', '100%', 'inline-block', 'center', 'rgb(95, 4, 4)', 'white', '0.8em', JSON.parse(RESPONSE__Json_DATA.Data).goal_message_text));
//   }
// }
// window.setInterval('SYNC______()', 100);

// function Shipping_banner(min_width, vertical_align, padding, font_family, width, height, display, text_align, background, color, font_size, text_message) {
//   return `
//     <div class="container announcement" id="NWS_announcement_message_bar--id">
//         <div class="row">
//             <div class="col-sm-12">
//                 <div class="announcement_message_bar_text" id="announcement_message_bar_text-id">`+ text_message + `</div>
//             </div>
//         </div>
//     </div>
//     <style>
//       .announcement {
//         display: `+ display + `;
//         height: `+ height + `;
//         text-align: `+ text_align + `;
//         width: `+ width + `;
//         background: `+ background + `;
//         color: `+ color + `;
//         font-family: `+ font_family + `;
//         margin: 0;
//         padding: `+ padding + `;
//         vertical-align: `+ vertical_align + `;
//         font-size: `+ font_size + `;
//         min-width: `+ min_width + `;
//         min-height: 30px !important;
//       }div#NWS_announcement_message_bar--id {
//         min-width: `+ min_width + `;
//       }
//     </style>

//   `;
// }

